package com.shivdhaba.food_delivery.domain.enums;

public enum ItemStatus {
    AVAILABLE,
    OUT_OF_STOCK,
    DISCONTINUED
}


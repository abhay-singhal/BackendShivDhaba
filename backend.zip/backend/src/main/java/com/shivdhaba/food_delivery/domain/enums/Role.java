package com.shivdhaba.food_delivery.domain.enums;

public enum Role {
    CUSTOMER,
    DELIVERY_BOY,
    ADMIN
}


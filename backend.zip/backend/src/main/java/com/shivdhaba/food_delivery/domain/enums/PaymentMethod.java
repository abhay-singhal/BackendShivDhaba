package com.shivdhaba.food_delivery.domain.enums;

public enum PaymentMethod {
    COD,
    RAZORPAY,
    ONLINE
}


//package com.shivdhaba.food_delivery;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class ShivDhabaFoodDeliveryApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
